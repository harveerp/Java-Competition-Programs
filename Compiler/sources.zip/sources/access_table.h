#ifndef _ACCESS_TABLE_H_
#define _ACCESS_TABLE_H_

void atable_init();
void insert_atable( int, int );
int retrieve_atable( int );
void print_atable();

#endif
