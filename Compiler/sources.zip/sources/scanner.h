#ifndef _SCANNER_H_
#define _SCANNER_H_

TOKEN 	gettoken();


/* STATES */
#define START	     	200
#define	PUNCTUATION  	202
#define COLON	     	206


#endif
