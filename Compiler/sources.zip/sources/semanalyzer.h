#ifndef _SEMANALYZER_H_
#define _SEMANALYZER_H_

void do_semantic_analysis();

#endif
