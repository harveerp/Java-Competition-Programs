#ifndef _INTERM_CODEGEN_H_
#define _INTERM_CODEGEN_H_

void generate_interm_code();

#endif

