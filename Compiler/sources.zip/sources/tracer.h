#ifndef _TRACER_H_
void parse_trace( int, int );
void tracer_init( int, int );

#endif

